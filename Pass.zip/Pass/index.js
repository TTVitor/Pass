import inquirer from 'inquirer';
import fs from 'fs';
import path from 'path';

const FILE_PATH = path.resolve('senhas.json');

function generatePassword(length, options) {
  const chars = {
    lower: 'abcdefghijklmnopqrstuvwxyz',
    upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    number: '0123456789',
    symbol: '!@#$%^&*()_+[]{}<>?'
  };

  let pool = '';
  if (options.lower) pool += chars.lower;
  if (options.upper) pool += chars.upper;
  if (options.number) pool += chars.number;
  if (options.symbol) pool += chars.symbol;

  if (!pool) return '';

  return Array.from({ length }, () => pool[Math.floor(Math.random() * pool.length)]).join('');
}

function loadPasswords() {
  if (!fs.existsSync(FILE_PATH)) return [];
  const data = fs.readFileSync(FILE_PATH, 'utf-8');
  try {
    return JSON.parse(data);
  } catch {
    return [];
  }
}

function saveAllPasswords(passwords) {
  fs.writeFileSync(FILE_PATH, JSON.stringify(passwords, null, 2));
}

function savePassword(entry) {
  const passwords = loadPasswords();
  passwords.push(entry);
  saveAllPasswords(passwords);
}

function displayPasswords() {
  const passwords = loadPasswords();
  if (passwords.length === 0) {
    console.log('\nNenhuma senha salva ainda.\n');
    return;
  }

  console.log('\nSenhas salvas:\n');
  passwords.forEach((entry, index) => {
    console.log(`${index + 1}. ${entry.name}: ${entry.password}`);
  });
  console.log('');
}

async function editPasswordDescription() {
  const passwords = loadPasswords();
  if (passwords.length === 0) {
    console.log('\nNenhuma senha para editar.\n');
    return;
  }

  const { index } = await inquirer.prompt({
    type: 'list',
    name: 'index',
    message: 'Qual descrição você quer alterar?',
    choices: passwords.map((p, i) => ({ name: `${p.name}: ${p.password}`, value: i }))
  });

  const { newName } = await inquirer.prompt({
    name: 'newName',
    message: 'Nova descrição:'
  });

  passwords[index].name = newName;
  saveAllPasswords(passwords);
  console.log('\n✅ Descrição atualizada!\n');
}

async function deletePassword() {
  const passwords = loadPasswords();
  if (passwords.length === 0) {
    console.log('\nNenhuma senha para excluir.\n');
    return;
  }

  const { index } = await inquirer.prompt({
    type: 'list',
    name: 'index',
    message: 'Qual senha você quer excluir?',
    choices: passwords.map((p, i) => ({ name: `${p.name}: ${p.password}`, value: i }))
  });

  const { confirm } = await inquirer.prompt({
    type: 'confirm',
    name: 'confirm',
    message: 'Tem certeza que deseja excluir esta senha?'
  });

  if (confirm) {
    passwords.splice(index, 1);
    saveAllPasswords(passwords);
    console.log('\n🗑️ Senha excluída!\n');
  }
}

async function run() {
  const mainChoice = await inquirer.prompt({
    type: 'list',
    name: 'action',
    message: 'O que você quer fazer?',
    choices: [
      'Gerar nova senha',
      'Ver senhas salvas',
      'Editar descrição de uma senha',
      'Excluir uma senha',
      'Sair'
    ]
  });

  if (mainChoice.action === 'Gerar nova senha') {
    const answers = await inquirer.prompt([
      { name: 'name', message: 'Nome/descrição da senha:' },
      { name: 'length', message: 'Comprimento da senha:', default: 12, validate: val => val > 0 },
      { type: 'confirm', name: 'lower', message: 'Incluir letras minúsculas?' },
      { type: 'confirm', name: 'upper', message: 'Incluir letras maiúsculas?' },
      { type: 'confirm', name: 'number', message: 'Incluir números?' },
      { type: 'confirm', name: 'symbol', message: 'Incluir símbolos?' }
    ]);

    const password = generatePassword(Number(answers.length), answers);

    if (password === '') {
      console.log('\n⚠️ Nenhum tipo de caractere foi selecionado. Tente novamente.\n');
    } else {
      savePassword({ name: answers.name, password });
      console.log('\n✅ Senha gerada e salva com sucesso!');
      console.log('Senha:', password, '\n');
    }
    run();
  } else if (mainChoice.action === 'Ver senhas salvas') {
    displayPasswords();
    run();
  } else if (mainChoice.action === 'Editar descrição de uma senha') {
    await editPasswordDescription();
    run();
  } else if (mainChoice.action === 'Excluir uma senha') {
    await deletePassword();
    run();
  } else {
    console.log('\nAté logo!\n');
    process.exit();
  }
}

run();
